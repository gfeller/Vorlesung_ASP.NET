﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BmiRechner.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
